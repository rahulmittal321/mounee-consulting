<?php
/**
 * Mounee Consulting Theme Functions
 *
 * @package Mounee_Consulting
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Theme Setup
 */
function mounee_consulting_setup() {
    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails
    add_theme_support( 'post-thumbnails' );

    // Custom logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Register navigation menus
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'mounee-consulting' ),
        'footer'  => __( 'Footer Menu', 'mounee-consulting' ),
    ) );

    // Switch default core markup to output valid HTML5
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ) );

    // Add support for responsive embedded content
    add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'mounee_consulting_setup' );

/**
 * Enqueue scripts and styles
 */
function mounee_consulting_scripts() {
    // Google Fonts
    wp_enqueue_style( 'mounee-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap', array(), null );

    // Main stylesheet
    wp_enqueue_style( 'mounee-consulting-style', get_template_directory_uri() . '/assets/css/main.css', array(), '1.0.0' );

    // Main JavaScript
    wp_enqueue_script( 'mounee-consulting-script', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true );

    // Comment reply script
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'mounee_consulting_scripts' );

/**
 * Register widget areas
 */
function mounee_consulting_widgets_init() {
    // Footer Widget Area 1
    register_sidebar( array(
        'name'          => __( 'Footer Widget 1', 'mounee-consulting' ),
        'id'            => 'footer-1',
        'description'   => __( 'Add widgets here to appear in your footer.', 'mounee-consulting' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    // Footer Widget Area 2
    register_sidebar( array(
        'name'          => __( 'Footer Widget 2', 'mounee-consulting' ),
        'id'            => 'footer-2',
        'description'   => __( 'Add widgets here to appear in your footer.', 'mounee-consulting' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    // Footer Widget Area 3
    register_sidebar( array(
        'name'          => __( 'Footer Widget 3', 'mounee-consulting' ),
        'id'            => 'footer-3',
        'description'   => __( 'Add widgets here to appear in your footer.', 'mounee-consulting' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'mounee_consulting_widgets_init' );

/**
 * Customizer additions
 */
function mounee_consulting_customize_register( $wp_customize ) {
    
    // Hero Section
    $wp_customize->add_section( 'mounee_hero_section', array(
        'title'    => __( 'Hero Section', 'mounee-consulting' ),
        'priority' => 30,
    ) );

    // Hero Title
    $wp_customize->add_setting( 'mounee_hero_title', array(
        'default'           => 'Helping Companies Hire the Right Talent',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'mounee_hero_title', array(
        'label'   => __( 'Hero Title', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'text',
    ) );

    // Hero Subtitle
    $wp_customize->add_setting( 'mounee_hero_subtitle', array(
        'default'           => 'Expert recruitment solutions for finding exceptional talent that drives your business forward.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ) );

    $wp_customize->add_control( 'mounee_hero_subtitle', array(
        'label'   => __( 'Hero Subtitle', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'textarea',
    ) );

    // Primary CTA Text
    $wp_customize->add_setting( 'mounee_hero_cta_primary', array(
        'default'           => 'Find Your Next Hire',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'mounee_hero_cta_primary', array(
        'label'   => __( 'Primary CTA Button Text', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'text',
    ) );

    // Primary CTA Link
    $wp_customize->add_setting( 'mounee_hero_cta_primary_link', array(
        'default'           => '#contact',
        'sanitize_callback' => 'esc_url_raw',
    ) );

    $wp_customize->add_control( 'mounee_hero_cta_primary_link', array(
        'label'   => __( 'Primary CTA Button Link', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'url',
    ) );

    // Secondary CTA Text
    $wp_customize->add_setting( 'mounee_hero_cta_secondary', array(
        'default'           => 'Our Services',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'mounee_hero_cta_secondary', array(
        'label'   => __( 'Secondary CTA Button Text', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'text',
    ) );

    // Secondary CTA Link
    $wp_customize->add_setting( 'mounee_hero_cta_secondary_link', array(
        'default'           => '#services',
        'sanitize_callback' => 'esc_url_raw',
    ) );

    $wp_customize->add_control( 'mounee_hero_cta_secondary_link', array(
        'label'   => __( 'Secondary CTA Button Link', 'mounee-consulting' ),
        'section' => 'mounee_hero_section',
        'type'    => 'url',
    ) );

    // Contact Section
    $wp_customize->add_section( 'mounee_contact_section', array(
        'title'    => __( 'Contact Information', 'mounee-consulting' ),
        'priority' => 35,
    ) );

    // Email Address
    $wp_customize->add_setting( 'mounee_contact_email', array(
        'default'           => 'parul.sharma@mouneeconsulting.org',
        'sanitize_callback' => 'sanitize_email',
    ) );

    $wp_customize->add_control( 'mounee_contact_email', array(
        'label'   => __( 'Email Address', 'mounee-consulting' ),
        'section' => 'mounee_contact_section',
        'type'    => 'email',
    ) );

    // Phone Number
    $wp_customize->add_setting( 'mounee_contact_phone', array(
        'default'           => '+91 XXX XXX XXXX',
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    $wp_customize->add_control( 'mounee_contact_phone', array(
        'label'   => __( 'Phone Number', 'mounee-consulting' ),
        'section' => 'mounee_contact_section',
        'type'    => 'text',
    ) );

    // Address
    $wp_customize->add_setting( 'mounee_contact_address', array(
        'default'           => 'India',
        'sanitize_callback' => 'sanitize_textarea_field',
    ) );

    $wp_customize->add_control( 'mounee_contact_address', array(
        'label'   => __( 'Address', 'mounee-consulting' ),
        'section' => 'mounee_contact_section',
        'type'    => 'textarea',
    ) );
}
add_action( 'customize_register', 'mounee_consulting_customize_register' );

/**
 * Custom template tags for this theme
 */

// Display custom logo or site title
function mounee_consulting_logo() {
    if ( has_custom_logo() ) {
        the_custom_logo();
    } else {
        ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title">
            <?php bloginfo( 'name' ); ?>
        </a>
        <?php
    }
}
